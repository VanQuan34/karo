<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Ftc_Gallery_Instagram extends Widget_Base {

	public function get_name() {
		return 'ftc-gallery-instagram';
	}

	public function get_title() {
		return __( 'FTC - Gallery Instagram ', 'ftc-element' );
	}

	public function get_icon() {
		return 'ftc-icon';
	}

	public function get_categories() {
		return [ 'ftc-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Gallery settings', 'ftc-element' ),   //section name for controler view
			]
		);

		$this->add_control(
			'username',
			[
				'label'       => __( 'Username or #tag : ', 'ftc-element' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Example: themeftc', 'ftc-element' ),
				'default'     => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'wp_gallery',
			[
				'label' => __( 'Add Images', 'ftc-element' ),
				'type' => Controls_Manager::GALLERY,
				'show_label' => false,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$this->add_control(
			'columns',
			[
				'label'   => __( 'Number of columns', 'ftc-element' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 5,
				'options' => [
					1  => __( '1', 'ftc-element' ),
					2  => __( '2', 'ftc-element' ),
					3  => __( '3', 'ftc-element' ),
					4  => __( '4', 'ftc-element' ),
					5  => __( '5', 'ftc-element' ),
					6  => __( '6', 'ftc-element' ),
				],
			]
		);

		$this->add_control(
			'size',
			[
				'label'       => esc_html__( 'Images size', 'ftc-element' ),
				'description' => '',
				'type'        => Controls_Manager::SELECT,
				'default'     => 'thumbnail',
				'options'     => [
					'thumbnail' => esc_html__( 'Thumbnail', 'ftc-element' ),
					'small'     => esc_html__( 'Small', 'ftc-element' ),
					'large'     => esc_html__( 'Large', 'ftc-element' ),
					'original'  => esc_html__( 'Original', 'ftc-element' ),

				],
			]
		);
		$this->add_control(
			'target',
			[
				'label'       => esc_html__( 'Target', 'ftc-element' ),
				'description' => '',
				'type'        => Controls_Manager::SELECT,
				'default'     => '_self',
				'options'     => [
					'_self' => esc_html__( 'Self', 'ftc-element' ),
					'_blank'     => esc_html__( 'New tab', 'ftc-element' ),
				],
			]
		);
		$this->add_control(
			'button',
			[
				'label'   => __( 'Button Follow', 'ftc-element' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_responsive_control(
			'button_align',
			[
				'label'     => __( 'Button Alignment', 'ftc-element' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'ftc-element' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ftc-element' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ftc-element' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ftc-instagram .button-insta' => 'text-align: {{VALUE}};',
				],

			]
		);
		$this->add_control(
			'padding_spacing',
			[
				'label'     => __( 'Padding beetween items', 'ftc-element' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => '',
				],
				'range'     => [
					'px' => [
						'max'  => 50,
						'min'  => 0,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ftc-instagram ul li' => 'padding-left:{{SIZE}}px;padding-right:{{SIZE}}px;',
				],

			]
		);
		$this->add_control(
			'hover_animation',
			[
				'label' => __( 'Hover animation', 'ftc-element' ),
				'type'  => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings           = $this->get_settings();
		$username           = $settings['username'];
		$wp_gallery         = $settings['wp_gallery'];
		$size               = $settings['size'];
		$target             = $settings['target'];
		$columns            = $settings['columns'];
		$button             = $settings['button'];
		$hover_animation    = $settings['hover_animation'];


		$image_ids = wp_list_pluck( $settings['wp_gallery'], 'id' );
		$link_insta = 'https://instagram.com/'.esc_attr($username);


		$this->add_render_attribute( 'ul-class', 'class', 'columns-' . $columns );
		$this->add_render_attribute( 'ul-class', 'class', $size );
		?>

		<div class="ftc-instagram">

			<ul <?php echo $this->get_render_attribute_string( 'ul-class' ); ?>>
				<?php 
				foreach( $image_ids as $image_id ){
					$images = wp_get_attachment_image_src( $image_id, $size );
					echo'<li class="images"><a href="'.esc_url($link_insta).'" target="'.esc_attr($target).'"><img src="'.$images[0].'" class="elementor-animation-'.esc_attr($hover_animation).'" alt="'.esc_attr($username).'" title="@'.esc_attr($username).'"></a></li>';
					$images++;
				}
				?>
			</ul>
			<?php 
			if($button){
				echo '<div class="button-insta"><i class="fa fa-instagram"></i><a href="' . esc_url( $link_insta ) . '" class="instagram-user">' . esc_html__( 'Follow', 'ftc-element' ) . ' ' . esc_html( $username ) . '</a></div>';
			}
			?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Ftc_Gallery_Instagram() );
